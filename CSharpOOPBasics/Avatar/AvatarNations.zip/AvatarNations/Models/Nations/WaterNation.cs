﻿class WaterNation : Nation
{
}