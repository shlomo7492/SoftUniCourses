﻿class AirNation : Nation
{
}