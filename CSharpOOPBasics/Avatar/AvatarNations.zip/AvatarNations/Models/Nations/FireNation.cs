﻿class FireNation:Nation
{
}