﻿class EarthNation : Nation
{
}